import math
import operator
import random
from unicodedata import category
from unittest import result


# input the file path
# return the data in the file spilted into 2 dimensional list
def get_alldata(file):
    final_alldata = []

    F = open(file, 'r')  # read the data in the file
    Str = F.read()  # get the value of the file
    F.close()  # no need to use the file object again

    alldata = Str.split('\n')

    row_data_final = []
    for x in range(len(alldata)):
        row_data = alldata[x]
        row_data = row_data.split(',')
        for i in range(4):
            row_data[i] = float(row_data[i])
        row_data_final = [row_data[:4], row_data[4]]
        final_alldata.append(row_data_final)

    return final_alldata


# input the datalist and return a mixed list
def mix_data(alldata):
    mixeddata = []
    for x in alldata:
        mixeddata.append(x)
    random.shuffle(mixeddata)
    return mixeddata


def get_learing_data(mixed_data):
    flag = int(len(mixed_data) * 0.8)
    learning_data = mixed_data[:flag]  # set the first 80% data as learning data
    return learning_data


def get_testing_data(mixed_data):
    flag = int(len(mixed_data) * 0.8)
    testing_data = mixed_data[flag:]  # set the last 20% data as testing data
    return testing_data


def get_distance(vector1, vector2):
    distance = 0
    if (len(vector1) == len(vector2)):
        for i in range(len(vector1)):
            distance += (vector1[i] - vector2[i]) ** 2
    distance = math.sqrt(distance)

    return distance


def swap_row(list, index1, index2):
    result_list = []

    for x in list:
        result_list.append(x)

    buffer = result_list[index1]
    result_list[index1] = result_list[index2]
    result_list[index2] = buffer

    return result_list


def get_k_neighbour(k, test, learning_data):
    k_neighbour = []
    distance = []
    for i in range(len(learning_data)):
        distance.append([i, get_distance(learning_data[i][0], test[0])])
    # calculate all the distance and store the distance with the index in learning data

    # sort the distance and find k distance
    n = len(learning_data)
    for i in range(n):
        for j in range(n - i - 1):
            if (distance[j][1] > distance[j + 1][1]):
                distance = swap_row(distance, j, j + 1)

    for i in range(k):
        k_neighbour.append(learning_data[i])

    return k_neighbour


def get_predict(k_neighbour):
    vote = {}
    for i in range(len(k_neighbour)):
        category = k_neighbour[i][-1]
        if (category in k_neighbour):
            vote[category] += 1
        else:
            vote[category] = 1

    max_key = max(vote, key=vote.get)

    return max_key


def study_and_testing():
    get_alldata('iris_data.txt')
    alldata = get_alldata('iris_data.txt')

    mixed_data = mix_data(alldata)

    learning_data = get_learing_data(mixed_data)

    testing_data = get_testing_data(mixed_data)

    # print(get_distance(learning_data[0][0],learning_data[1][0]))

    k = 4

    # k_neighbour = get_k_neighbour(k, testing_data[0], learning_data)
    # str = get_predict(k_neighbour)
    predict = []
    for i in range(len(testing_data)):
        k_neighbour = get_k_neighbour(k, testing_data[i], learning_data)
        str = get_predict(k_neighbour)
        predict.append(str)

    truth = 0
    for i in range(len(testing_data)):
        print(predict[i] + " " +testing_data[i][-1])
        if (predict[i] == testing_data[i][-1]):
            truth += 1


    print("%.2f%%" % (truth/len(testing_data)*100))
    # print("%f\%"%(truth/len(testing_data)*100))
    return 0


if __name__ == "__main__":
    study_and_testing()


